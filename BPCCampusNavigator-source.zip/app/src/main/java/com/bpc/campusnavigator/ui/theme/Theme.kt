package com.bpc.campusnavigator.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BpcDarkGreen = Color(0xFF0B4F26)
val BpcGreen = Color(0xFF1B7F3F)
val BpcMint = Color(0xFFDDF3E3)
val BpcGold = Color(0xFFF2B705)
val BpcBg = Color(0xFFF1F6F1)
val BpcText = Color(0xFF12301E)
val BpcMuted = Color(0xFF3F7A57)

@Composable
fun BpcTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = BpcGreen,
            onPrimary = Color.White,
            secondary = BpcGold,
            background = BpcBg,
            surface = Color.White,
            onSurface = BpcText,
        ),
        content = content
    )
}
