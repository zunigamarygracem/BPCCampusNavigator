package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.AuthState
import com.bpc.campusnavigator.classes
import com.bpc.campusnavigator.placeById
import com.bpc.campusnavigator.ui.theme.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun ScheduleScreen(onLocate: (String) -> Unit) {
    val currentUserEmail = AuthState.currentUser.value?.email

    ScreenScaffold("Schedule", "Class hours & school activities") {
        if (currentUserEmail == null) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("Sign In Required", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = BpcText)
                Spacer(Modifier.height(8.dp))
                Text("Please sign in to your account to view your class schedules.", fontSize = 14.sp, color = BpcMuted)
            }
        } else {
            val days = DayOfWeek.values().filter { it != DayOfWeek.SUNDAY }
            val today = LocalDate.now().dayOfWeek.let { if (it == DayOfWeek.SUNDAY) DayOfWeek.MONDAY else it }
            var day by remember { mutableStateOf(today) }

            val list = classes.filter { c ->
                c.day == day && (c.userEmail.equals("all", true) || c.userEmail.equals(currentUserEmail, true))
            }

            LazyRow(
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(days) { d ->
                    FilterChip(
                        selected = d == day, onClick = { day = d },
                        label = { Text(d.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BpcGreen, selectedLabelColor = Color.White,
                            containerColor = Color.White,
                        ),
                    )
                }
            }
            if (list.isEmpty()) {
                Text("No classes on this day.", color = BpcMuted, modifier = Modifier.padding(24.dp))
            }
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(list) { c ->
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                    ) {
                        Row(Modifier.padding(16.dp)) {
                            Box(Modifier.width(5.dp).height(64.dp).background(BpcGreen, RoundedCornerShape(50)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(c.time, fontSize = 13.sp, color = BpcMuted, fontWeight = FontWeight.SemiBold)
                                    if (!c.userEmail.equals("all", true)) {
                                        Surface(shape = RoundedCornerShape(50), color = BpcMint) {
                                            Text("For: ${c.userEmail}", fontSize = 10.sp, color = BpcDarkGreen, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    }
                                }
                                Text(c.subject, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = BpcText)
                                Text(
                                    "${placeById(c.roomId)?.name ?: ""}  -  ${c.instructor}",
                                    fontSize = 13.sp, color = BpcMuted,
                                )
                            }
                            TextButton(onClick = { onLocate(c.roomId) }) { Text("Locate", color = BpcGreen) }
                        }
                    }
                }
            }
        }
    }
}
