package com.bpc.campusnavigator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.bpc.campusnavigator.ui.screens.*
import com.bpc.campusnavigator.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { BpcTheme { BpcApp() } }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("map", "Map", Icons.Outlined.Map),
    Tab("schedule", "Schedule", Icons.Outlined.CalendarMonth),
    Tab("announcements", "Announcements", Icons.Outlined.Notifications),
    Tab("profile", "Profile", Icons.Outlined.Person),
)

private fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = false }
        launchSingleTop = true
    }
}

@Composable
fun BpcApp() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route?.substringBefore("?")

    val openMap: (String) -> Unit = { id -> nav.navigate("map?place=$id") { launchSingleTop = true } }
    val openRoute: (String) -> Unit = { id -> nav.navigate("route?to=$id") { launchSingleTop = true } }
    val openFromHome: (String) -> Unit = { dest ->
        when (dest) {
            "home", "map", "schedule", "announcements", "profile" -> nav.goTab(dest)
            else -> nav.navigate(dest) { launchSingleTop = true }
        }
    }

    Scaffold(
        containerColor = BpcBg,
        bottomBar = {
            if (current != null && current != "splash") {
                NavigationBar(containerColor = Color.White) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = current == t.route,
                            onClick = { nav.goTab(t.route) },
                            icon = { Icon(t.icon, t.label) },
                            label = { Text(t.label, fontSize = 11.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BpcDarkGreen, selectedTextColor = BpcDarkGreen,
                                unselectedIconColor = BpcMuted, unselectedTextColor = BpcMuted,
                                indicatorColor = BpcMint,
                            ),
                        )
                    }
                }
            }
        },
    ) { inner ->
        // Screens draw edge-to-edge at the top; only the bottom bar inset is applied.
        NavHost(
            navController = nav,
            startDestination = "splash",
            modifier = Modifier.fillMaxSize().padding(bottom = inner.calculateBottomPadding()),
        ) {
            composable("splash") {
                SplashScreen(onStart = {
                    nav.navigate("home") { popUpTo("splash") { inclusive = true } }
                })
            }
            composable("home") { HomeScreen(onOpen = openFromHome) }
            composable(
                "map?place={place}",
                arguments = listOf(navArgument("place") { type = NavType.StringType; nullable = true; defaultValue = null }),
            ) { e ->
                CampusMapScreen(initialPlaceId = e.arguments?.getString("place"), onRoute = openRoute)
            }
            composable(
                "route?to={to}",
                arguments = listOf(navArgument("to") { type = NavType.StringType; nullable = true; defaultValue = null }),
            ) { e ->
                RouteGuideScreen(initialToId = e.arguments?.getString("to"), onBack = { nav.popBackStack() })
            }
            composable("directory") { DirectoryScreen(onBack = { nav.popBackStack() }, onLocate = openMap) }
            composable("schedule") { ScheduleScreen(onLocate = openMap) }
            composable("announcements") { AnnouncementsScreen() }
            composable("resources") { ResourcesScreen(onBack = { nav.popBackStack() }, onLocate = openMap) }
            composable("profile") {
                ProfileScreen(
                    onOpenAdmin = { nav.navigate("admin_map") { launchSingleTop = true } },
                    onNavigateSignIn = { nav.navigate("signin") { launchSingleTop = true } },
                    onNavigateSignUp = { nav.navigate("signup") { launchSingleTop = true } },
                )
            }
            composable("signin") {
                SignInScreen(
                    onSuccess = { nav.popBackStack() },
                    onNavigateSignUp = { nav.navigate("signup") { launchSingleTop = true; popUpTo("signin") { inclusive = true } } },
                    onBack = { nav.popBackStack() },
                )
            }
            composable("signup") {
                SignUpScreen(
                    onSuccess = { nav.popBackStack() },
                    onNavigateSignIn = { nav.navigate("signin") { launchSingleTop = true; popUpTo("signup") { inclusive = true } } },
                    onBack = { nav.popBackStack() },
                )
            }
            composable("admin_map") { AdminMapScreen(onBack = { nav.popBackStack() }) }
        }
    }
}
