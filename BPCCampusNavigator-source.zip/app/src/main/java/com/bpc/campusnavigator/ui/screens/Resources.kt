package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.resources
import com.bpc.campusnavigator.ui.theme.*

@Composable
fun ResourcesScreen(onBack: () -> Unit, onLocate: (String) -> Unit) {
    ScreenScaffold("Resources", "Library, facilities & more", onBack) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(resources) { r ->
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth().clickable(enabled = r.placeId != null) { onLocate(r.placeId!!) },
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).background(BpcMint, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(r.icon, null, tint = BpcDarkGreen, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(r.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = BpcText)
                            Text(r.desc, fontSize = 13.sp, color = BpcMuted)
                        }
                    }
                }
            }
        }
    }
}
