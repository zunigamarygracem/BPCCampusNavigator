package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.offices
import com.bpc.campusnavigator.placeById
import com.bpc.campusnavigator.ui.theme.*

@Composable
fun DirectoryScreen(onBack: () -> Unit, onLocate: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    val list = offices.filter { it.name.contains(query, ignoreCase = true) }

    ScreenScaffold("Directory", "Offices, departments & contacts", onBack) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Search offices...") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            singleLine = true, shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                focusedBorderColor = BpcGreen, unfocusedBorderColor = BpcMint,
            ),
            modifier = Modifier.fillMaxWidth().padding(16.dp),
        )
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(list) { o ->
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(o.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = BpcText)
                        InfoRow(Icons.Outlined.LocationOn, placeById(o.placeId)?.name ?: "")
                        InfoRow(Icons.Outlined.Schedule, o.hours)
                        InfoRow(Icons.Outlined.Email, o.contact)
                        OutlinedButton(onClick = { onLocate(o.placeId) }) { Text("Locate on map", color = BpcGreen) }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = BpcGreen, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = BpcMuted, fontSize = 14.sp)
    }
}
