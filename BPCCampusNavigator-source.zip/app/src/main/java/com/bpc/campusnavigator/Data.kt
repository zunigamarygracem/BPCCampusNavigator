package com.bpc.campusnavigator

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector
import java.time.DayOfWeek

/** x / y are fractions (0..1) of the campus map image. */
data class Place(
    val id: String,
    val name: String,
    val x: Float,
    val y: Float,
    val category: String,
    val desc: String,
)

// Positions were measured from the Campus Directory map (900 x 636 reference grid).
val initialPlaces = listOf(
    Place("library", "Library", 252 / 900f, 244 / 636f, "Academic", "Books, study areas and research materials."),
    Place("canteen", "Canteen", 362 / 900f, 202 / 636f, "Facilities", "Food and refreshments for students and staff."),
    Place("ptca", "PTCA Office", 343 / 900f, 310 / 636f, "Offices", "Parent-Teacher-Community Association office (1st floor)."),
    Place("faculty", "Faculty Room", 350 / 900f, 331 / 636f, "Offices", "Faculty offices (1st floor)."),
    Place("comlab", "Computer Labs 3-4", 350 / 900f, 356 / 636f, "Academic", "Computer laboratories (2nd floor)."),
    Place("main", "Main Building", 638 / 900f, 317 / 636f, "Academic", "Main academic building and classrooms."),
    Place("court1", "Covered Court 1", 638 / 900f, 197 / 636f, "Facilities", "Covered court for sports and school events."),
    Place("court2", "Covered Court 2", 303 / 900f, 498 / 636f, "Facilities", "Secondary covered court."),
    Place("activity", "Activity Center", 305 / 900f, 544 / 636f, "Facilities", "Events, programs and gatherings."),
    Place("admin", "Admin Building", 566 / 900f, 509 / 636f, "Offices", "Registrar, cashier and administrative offices."),
    Place("bldgb", "Building B", 766 / 900f, 509 / 636f, "Academic", "Additional classrooms."),
    Place("hrs", "HRS Building", 127 / 900f, 212 / 636f, "Academic", "HRS department building."),
    Place("eim", "EIM / SMA", 158 / 900f, 212 / 636f, "Academic", "EIM / SMA rooms."),
    Place("css", "CSS", 158 / 900f, 265 / 636f, "Academic", "CSS room."),
    Place("eca", "ECA Lab", 158 / 900f, 298 / 636f, "Academic", "ECA laboratory."),
    Place("exit1", "Exit 1", 618 / 900f, 357 / 636f, "Exits", "Campus exit near the Main Building."),
    Place("exit2", "Exit 2", 815 / 900f, 383 / 636f, "Exits", "Campus exit on the east side."),
    Place("exit3", "Exit 3", 443 / 900f, 408 / 636f, "Exits", "Campus exit near the service roadway."),
    Place("exit4", "Exit 4", 188 / 900f, 419 / 636f, "Exits", "Campus exit on the west side."),
)

val places = mutableStateListOf<Place>().apply {
    addAll(initialPlaces)
}

fun addPlace(place: Place) {
    val index = places.indexOfFirst { it.id == place.id }
    if (index >= 0) {
        places[index] = place
    } else {
        places.add(place)
    }
}

fun updatePlace(place: Place) {
    val index = places.indexOfFirst { it.id == place.id }
    if (index >= 0) {
        places[index] = place
    }
}

fun deletePlace(id: String) {
    places.removeIf { it.id == id }
}

fun placeById(id: String?): Place? = places.firstOrNull { it.id == id }

data class Office(val name: String, val placeId: String, val hours: String, val contact: String)

val initialOffices = listOf(
    Office("Registrar's Office", "admin", "Mon-Fri, 8:00 AM - 5:00 PM", "registrar@bpc.edu.ph"),
    Office("Cashier", "admin", "Mon-Fri, 8:00 AM - 4:00 PM", "cashier@bpc.edu.ph"),
    Office("Admission Office", "admin", "Mon-Fri, 8:00 AM - 5:00 PM", "admission@bpc.edu.ph"),
    Office("Guidance Office", "main", "Mon-Fri, 8:00 AM - 5:00 PM", "guidance@bpc.edu.ph"),
    Office("Faculty Room", "faculty", "Mon-Sat, 7:00 AM - 6:00 PM", "faculty@bpc.edu.ph"),
    Office("PTCA Office", "ptca", "Mon-Fri, 8:00 AM - 5:00 PM", "ptca@bpc.edu.ph"),
    Office("Library", "library", "Mon-Sat, 7:30 AM - 6:00 PM", "library@bpc.edu.ph"),
    Office("Computer Laboratories", "comlab", "Mon-Sat, 7:30 AM - 6:00 PM", "itlab@bpc.edu.ph"),
)

val offices = mutableStateListOf<Office>().apply { addAll(initialOffices) }

fun addOffice(office: Office) { offices.add(office) }
fun updateOffice(oldOffice: Office, newOffice: Office) {
    val index = offices.indexOf(oldOffice)
    if (index >= 0) offices[index] = newOffice else offices.add(newOffice)
}
fun deleteOffice(office: Office) { offices.remove(office) }

data class ClassItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val userEmail: String = "all", // "all" or specific student email
    val day: DayOfWeek,
    val time: String,
    val subject: String,
    val roomId: String,
    val instructor: String,
)

val initialClasses = listOf(
    ClassItem(userEmail = "all", day = DayOfWeek.MONDAY, time = "8:00 - 10:00 AM", subject = "Accounting Information Systems", roomId = "main", instructor = "Prof. Santos"),
    ClassItem(userEmail = "all", day = DayOfWeek.MONDAY, time = "1:00 - 3:00 PM", subject = "Computer Programming", roomId = "comlab", instructor = "Prof. Reyes"),
    ClassItem(userEmail = "all", day = DayOfWeek.TUESDAY, time = "9:00 - 11:00 AM", subject = "Business Mathematics", roomId = "main", instructor = "Prof. Cruz"),
    ClassItem(userEmail = "all", day = DayOfWeek.TUESDAY, time = "1:00 - 3:00 PM", subject = "Database Management", roomId = "comlab", instructor = "Prof. Dela Cruz"),
    ClassItem(userEmail = "all", day = DayOfWeek.WEDNESDAY, time = "8:00 - 10:00 AM", subject = "Financial Accounting", roomId = "bldgb", instructor = "Prof. Garcia"),
    ClassItem(userEmail = "all", day = DayOfWeek.WEDNESDAY, time = "10:30 AM - 12:00 PM", subject = "Physical Education", roomId = "court1", instructor = "Coach Ramos"),
    ClassItem(userEmail = "all", day = DayOfWeek.THURSDAY, time = "9:00 - 11:00 AM", subject = "Systems Analysis & Design", roomId = "main", instructor = "Prof. Reyes"),
    ClassItem(userEmail = "all", day = DayOfWeek.FRIDAY, time = "8:00 - 10:00 AM", subject = "Business Communication", roomId = "bldgb", instructor = "Prof. Bautista"),
    ClassItem(userEmail = "all", day = DayOfWeek.FRIDAY, time = "1:00 - 3:00 PM", subject = "NSTP", roomId = "activity", instructor = "Prof. Villanueva"),
    ClassItem(userEmail = "all", day = DayOfWeek.SATURDAY, time = "8:00 - 11:00 AM", subject = "Research Methods", roomId = "library", instructor = "Prof. Mendoza"),
)

val classes = mutableStateListOf<ClassItem>().apply { addAll(initialClasses) }

fun addClassItem(item: ClassItem) { classes.add(item) }
fun updateClassItem(oldItem: ClassItem, newItem: ClassItem) {
    val index = classes.indexOf(oldItem)
    if (index >= 0) classes[index] = newItem else classes.add(newItem)
}
fun deleteClassItem(item: ClassItem) { classes.remove(item) }

data class Announcement(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val tag: String,
    val body: String,
)

val initialAnnouncements = listOf(
    Announcement(
        title = "Enrollment Schedule for AY 2025-2026", date = "Aug 27, 2025", tag = "Enrollment",
        body = "Be updated on the latest enrollment process and important reminders. Prepare your requirements and check your assigned schedule at the Registrar's Office."
    ),
    Announcement(
        title = "Campus Directory Now Available", date = "Aug 25, 2025", tag = "Update",
        body = "Use the Campus Map and Route Guide to find buildings, offices and facilities around the Bulacan Polytechnic College campus."
    ),
    Announcement(
        title = "Library Hours Extended", date = "Aug 20, 2025", tag = "Facilities",
        body = "The library will stay open until 6:00 PM on weekdays during the enrollment period."
    ),
)

val announcements = mutableStateListOf<Announcement>().apply {
    addAll(initialAnnouncements)
}

fun addAnnouncement(announcement: Announcement) {
    announcements.add(0, announcement)
}

fun updateAnnouncement(announcement: Announcement) {
    val index = announcements.indexOfFirst { it.id == announcement.id }
    if (index >= 0) {
        announcements[index] = announcement
    }
}

fun deleteAnnouncement(id: String) {
    announcements.removeIf { it.id == id }
}

data class Resource(val title: String, val desc: String, val icon: ImageVector, val placeId: String?)

val initialResources = listOf(
    Resource("Library", "Books, research and study areas", Icons.Outlined.MenuBook, "library"),
    Resource("Computer Laboratories", "COMLAB 3-4 - 2nd floor", Icons.Outlined.Computer, "comlab"),
    Resource("Canteen", "Food and refreshments", Icons.Outlined.Restaurant, "canteen"),
    Resource("Activity Center", "Events and programs", Icons.Outlined.Celebration, "activity"),
    Resource("Covered Courts", "Sports and school events", Icons.Outlined.SportsBasketball, "court1"),
    Resource("Admin Services", "Registrar, cashier & admission", Icons.Outlined.AccountBalance, "admin"),
)

val resources = mutableStateListOf<Resource>().apply { addAll(initialResources) }

fun addResource(resource: Resource) { resources.add(resource) }
fun updateResource(oldResource: Resource, newResource: Resource) {
    val index = resources.indexOf(oldResource)
    if (index >= 0) resources[index] = newResource else resources.add(newResource)
}
fun deleteResource(resource: Resource) { resources.remove(resource) }

data class User(
    val name: String,
    val email: String,
    val isAdmin: Boolean,
)

object AuthState {
    val currentUser = mutableStateOf<User?>(null)
}

val authorizedAdminIds = listOf("MA-00000000")
