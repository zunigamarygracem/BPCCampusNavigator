package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.R
import com.bpc.campusnavigator.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val textShadow = Shadow(Color.Black.copy(alpha = 0.45f), blurRadius = 8f)

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(BpcBg).verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth()) {
            Image(
                painterResource(R.drawable.header_bg), null,
                Modifier.fillMaxWidth().height(470.dp),
                contentScale = ContentScale.Crop, alignment = Alignment.TopCenter,
            )
            Box(
                Modifier.fillMaxWidth().height(470.dp).background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.15f),
                        0.45f to Color.Transparent,
                        1f to BpcBg,
                    )
                )
            )
            Column(Modifier.statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
                HeaderRow(onBell = { onOpen("announcements") }, onOpen = onOpen)
                Spacer(Modifier.height(36.dp))
                GreetingCard()
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureCard(Icons.Outlined.Map, "Campus Map", "Find buildings & locations", Modifier.weight(1f)) { onOpen("map") }
                    FeatureCard(Icons.Outlined.Route, "Route Guide", "Get the best route to your destination", Modifier.weight(1f)) { onOpen("route") }
                    FeatureCard(Icons.Outlined.Badge, "Directory", "Offices, departments & contacts", Modifier.weight(1f)) { onOpen("directory") }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureCard(Icons.Outlined.EditCalendar, "Schedule", "Class hours & school activities", Modifier.weight(1f)) { onOpen("schedule") }
                    FeatureCard(Icons.Outlined.Campaign, "Announcements", "Latest news & updates", Modifier.weight(1f)) { onOpen("announcements") }
                    FeatureCard(Icons.Outlined.MenuBook, "Resources", "Library, facilities & more", Modifier.weight(1f)) { onOpen("resources") }
                }
                Spacer(Modifier.height(16.dp))
                AnnouncementBanner { onOpen("announcements") }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun HeaderRow(onBell: () -> Unit, onOpen: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.bpc_seal), "BPC seal", Modifier.size(64.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "BPC CAMPUS\nNAVIGATOR", color = Color.White, fontWeight = FontWeight.ExtraBold,
                fontSize = 24.sp, lineHeight = 26.sp, style = TextStyle(shadow = textShadow),
            )
            Text(
                "Explore  \u2022  Navigate  \u2022  Succeed", color = Color.White, fontSize = 12.sp,
                style = TextStyle(shadow = textShadow),
            )
        }
        Box(Modifier.clip(CircleShape).clickable { onBell() }.padding(6.dp)) {
            Icon(Icons.Filled.Notifications, "Notifications", tint = Color.White, modifier = Modifier.size(30.dp))
            Box(Modifier.align(Alignment.TopEnd).size(10.dp).background(Color(0xFFE53935), CircleShape))
        }
        Box {
            Icon(
                Icons.Filled.Menu, "Menu", tint = Color.White,
                modifier = Modifier.clip(CircleShape).clickable { menu = true }.padding(6.dp).size(30.dp),
            )
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Route Guide") }, onClick = { menu = false; onOpen("route") })
                DropdownMenuItem(text = { Text("Directory") }, onClick = { menu = false; onOpen("directory") })
                DropdownMenuItem(text = { Text("Resources") }, onClick = { menu = false; onOpen("resources") })
            }
        }
    }
}

@Composable
private fun GreetingCard() {
    val today = remember {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, MMM d, yyyy", Locale.ENGLISH))
    }
    BoxWithConstraints(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(BpcDarkGreen.copy(alpha = 0.88f)).padding(16.dp)
    ) {
        val wide = maxWidth > 340.dp
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(64.dp).background(BpcGreen, CircleShape).border(2.dp, Color(0xFF7FD19A), CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(40.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Hello,", color = Color.White, fontSize = 15.sp)
                    Text("BPCian! \uD83D\uDC4B", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Your campus, your guide.", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                    Text("Let's make your BPC journey easier!", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                }
                if (wide) DatePill(today)
            }
            if (!wide) DatePill(today)
        }
    }
}

@Composable
private fun DatePill(today: String) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).border(1.dp, Color(0xFF4DB36E), RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.08f)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text("Today is", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
            Text(today, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FeatureCard(icon: ImageVector, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    BoxWithConstraints(modifier) {
        val narrow = maxWidth < 120.dp
        Card(
            onClick = onClick,
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.93f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            modifier = Modifier.fillMaxWidth().height(if (narrow) 148.dp else 160.dp),
        ) {
            Column(Modifier.padding(if (narrow) 8.dp else 12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Box(Modifier.size(if (narrow) 46.dp else 54.dp).background(BpcMint, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(icon, null, tint = BpcDarkGreen, modifier = Modifier.size(if (narrow) 26.dp else 30.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.size(24.dp).background(BpcMint, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = BpcDarkGreen, modifier = Modifier.size(14.dp))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    title, color = BpcText, fontWeight = FontWeight.Bold, maxLines = 1,
                    fontSize = if (narrow) 12.sp else 15.sp,
                )
                Text(
                    sub, color = BpcMuted, fontSize = if (narrow) 10.sp else 12.sp,
                    lineHeight = if (narrow) 13.sp else 15.sp,
                )
            }
        }
    }
}

@Composable
private fun AnnouncementBanner(onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(158.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(BpcDarkGreen, Color(0xFF0E6B33))))
    ) {
        Image(
            painterResource(R.drawable.banner_building), null,
            Modifier.align(Alignment.CenterEnd).fillMaxWidth(0.55f).fillMaxHeight(),
            contentScale = ContentScale.Crop,
        )
        Box(
            Modifier.matchParentSize().background(
                Brush.horizontalGradient(0.3f to BpcDarkGreen, 0.62f to BpcDarkGreen.copy(alpha = 0.6f), 1f to Color.Transparent)
            )
        )
        Column(Modifier.fillMaxWidth(0.68f).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF2E9E4F)).padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Outlined.Campaign, null, tint = Color.White, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text("Latest Announcement", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(
                "Enrollment Schedule\nfor AY 2025\u20132026", color = Color.White,
                fontWeight = FontWeight.Bold, fontSize = 17.sp, lineHeight = 20.sp,
            )
            Text(
                "Be updated on the latest enrollment process and important reminders.",
                color = Color.White.copy(alpha = 0.9f), fontSize = 11.sp, lineHeight = 14.sp, maxLines = 2,
            )
            Row(
                Modifier.clip(RoundedCornerShape(50)).border(BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), RoundedCornerShape(50))
                    .clickable { onClick() }.padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("View Details", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(4.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = Color.White, modifier = Modifier.size(14.dp))
            }
        }
    }
}
