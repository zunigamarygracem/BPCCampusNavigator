package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.Place
import com.bpc.campusnavigator.placeById
import com.bpc.campusnavigator.places
import com.bpc.campusnavigator.ui.theme.*
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max

@Composable
fun PlacePicker(label: String, value: Place?, onPick: (Place) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        Surface(
            shape = RoundedCornerShape(16.dp), color = Color.White,
            border = BorderStroke(1.dp, BpcMint), modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                Modifier.clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(label, fontSize = 12.sp, color = BpcMuted)
                    Text(value?.name ?: "Choose location", fontWeight = FontWeight.SemiBold, color = BpcText)
                }
                Icon(Icons.Filled.ArrowDropDown, null, tint = BpcGreen)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            places.forEach { p ->
                DropdownMenuItem(text = { Text(p.name) }, onClick = { onPick(p); open = false })
            }
        }
    }
}

@Composable
fun RouteGuideScreen(initialToId: String?, onBack: () -> Unit) {
    var from by remember { mutableStateOf<Place?>(placeById("exit1")) }
    var to by remember { mutableStateOf<Place?>(placeById(initialToId) ?: placeById("library")) }
    var selected by remember { mutableStateOf<Place?>(null) }

    ScreenScaffold("Route Guide", "Get the best route to your destination", onBack) {
        Column(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PlacePicker("From", from, { from = it })
                    PlacePicker("To", to, { to = it })
                }
                IconButton(onClick = { val t = from; from = to; to = t }) {
                    Icon(Icons.Filled.SwapVert, "Swap", tint = BpcGreen)
                }
            }
            val a = from
            val b = to
            CampusMapView(
                Modifier.fillMaxWidth().weight(1f),
                selected = selected, onSelect = { selected = it },
                route = if (a != null && b != null) a to b else null,
            )
            if (a != null && b != null) {
                // Approximate: assumes the map is about 225 m wide (reference grid 900 x 636).
                val px = hypot((b.x - a.x) * 900f, (b.y - a.y) * 636f)
                val meters = (px * 0.25f).toInt()
                val mins = max(1, ceil(meters / 80f).toInt())
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("${a.name}  ->  ${b.name}", fontWeight = FontWeight.Bold, color = BpcText)
                        Spacer(Modifier.height(4.dp))
                        Text("About $meters m  -  around $mins min walk", color = BpcMuted, fontSize = 14.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(b.desc, color = BpcMuted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
