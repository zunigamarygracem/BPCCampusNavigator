package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.R
import com.bpc.campusnavigator.ui.theme.*

@Composable
fun SplashScreen(onStart: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF6FB7EE), Color(0xFFD6EAF8)))
        )
    ) {
        Image(
            painterResource(R.drawable.splash_building), null,
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 56.dp),
            contentScale = ContentScale.FillWidth,
        )

        Column(
            Modifier.fillMaxWidth().statusBarsPadding().padding(top = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(painterResource(R.drawable.bpc_seal), "BPC seal", Modifier.size(180.dp))
            Spacer(Modifier.height(16.dp))
            Text(
                "BULACAN POLYTECHNIC\nCOLLEGE",
                color = BpcDarkGreen, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold,
                fontSize = 30.sp, lineHeight = 34.sp, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(90.dp).height(2.dp).background(BpcGold))
                Box(Modifier.padding(horizontal = 8.dp).size(9.dp).rotate(45f).background(BpcGreen))
                Box(Modifier.width(90.dp).height(2.dp).background(BpcGold))
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "MALOLOS, BULACAN  \u2022  EST. 1971",
                color = BpcDarkGreen, fontSize = 13.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Medium,
            )
        }

        Canvas(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(170.dp)) {
            val w = size.width
            val h = size.height
            val top = Path().apply {
                moveTo(0f, h * 0.18f)
                quadraticBezierTo(w * 0.5f, h * 0.85f, w, h * 0.18f)
            }
            val fill = Path().apply {
                moveTo(0f, h * 0.18f)
                quadraticBezierTo(w * 0.5f, h * 0.85f, w, h * 0.18f)
                lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(Color(0xFF13692F), BpcDarkGreen)))
            drawPath(top, BpcGold, style = Stroke(width = 5.dp.toPx()))
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(bottom = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Education Today,\nA Brighter Tomorrow",
                color = Color.White, fontFamily = FontFamily.Cursive, fontStyle = FontStyle.Italic,
                fontSize = 24.sp, lineHeight = 28.sp, textAlign = TextAlign.Center,
            )
            Box(Modifier.padding(top = 4.dp).width(150.dp).height(3.dp).clip(RoundedCornerShape(50)).background(BpcGold))
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier
                    .fillMaxWidth(0.66f).height(54.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF17773A), BpcDarkGreen)))
                    .border(1.5.dp, BpcGold, RoundedCornerShape(50))
                    .clickable { onStart() },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Get Started", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(10.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = Color.White)
            }
        }
    }
}
