package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.*
import com.bpc.campusnavigator.ui.theme.*
import java.time.DayOfWeek

private const val ADMIN_MAP_ASPECT = 1799f / 1272f

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMapScreen(onBack: () -> Unit) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0=Map, 1=Announcements, 2=Offices, 3=Classes, 4=Resources
    
    var showAddPlaceDialog by remember { mutableStateOf(false) }
    var editingPlace by remember { mutableStateOf<Place?>(null) }
    var selectedPlaceOnMap by remember { mutableStateOf<Place?>(null) }

    var showAddAnnouncementDialog by remember { mutableStateOf(false) }
    var editingAnnouncement by remember { mutableStateOf<Announcement?>(null) }

    var showAddOfficeDialog by remember { mutableStateOf(false) }
    var editingOffice by remember { mutableStateOf<Office?>(null) }

    var showAddClassDialog by remember { mutableStateOf(false) }
    var editingClassItem by remember { mutableStateOf<ClassItem?>(null) }

    var showAddResourceDialog by remember { mutableStateOf(false) }
    var editingResource by remember { mutableStateOf<Resource?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin Dashboard", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.Map, null, tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BpcDarkGreen),
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    when (selectedTab) {
                        0 -> showAddPlaceDialog = true
                        1 -> showAddAnnouncementDialog = true
                        2 -> showAddOfficeDialog = true
                        3 -> showAddClassDialog = true
                        4 -> showAddResourceDialog = true
                    }
                },
                containerColor = BpcGreen,
                contentColor = Color.White,
            ) {
                Icon(Icons.Filled.Add, null)
            }
        },
        containerColor = BpcBg,
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = BpcDarkGreen,
                edgePadding = 16.dp,
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Filled.Map, null) }, text = { Text("Map") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Filled.Campaign, null) }, text = { Text("Announcements") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Filled.Business, null) }, text = { Text("Offices") })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, icon = { Icon(Icons.Filled.Schedule, null) }, text = { Text("Schedule") })
                Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, icon = { Icon(Icons.Filled.Book, null) }, text = { Text("Resources") })
            }

            when (selectedTab) {
                0 -> {
                    // Map Locations
                    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Interactive Map Preview & Editor (Pinch to Zoom)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BpcText)
                        CampusMapView(
                            modifier = Modifier.fillMaxWidth().height(220.dp),
                            selected = selectedPlaceOnMap,
                            onSelect = { p ->
                                selectedPlaceOnMap = p
                                if (p != null) editingPlace = p
                            },
                        )
                        Text("All Locations (${places.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BpcText)
                        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(places, key = { it.id }) { place ->
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(place.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BpcText)
                                            Text(place.desc, fontSize = 12.sp, color = BpcMuted, maxLines = 1)
                                        }
                                        IconButton(onClick = { editingPlace = place }) { Icon(Icons.Filled.Edit, null, tint = BpcGreen) }
                                        IconButton(onClick = { deletePlace(place.id) }) { Icon(Icons.Filled.Delete, null, tint = Color(0xFFE53935)) }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // Announcements
                    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Announcements (${announcements.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BpcText)
                        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(announcements, key = { it.id }) { ann ->
                                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(ann.tag, fontSize = 11.sp, color = BpcDarkGreen, fontWeight = FontWeight.SemiBold)
                                            Spacer(Modifier.width(8.dp))
                                            Text(ann.date, fontSize = 12.sp, color = BpcMuted)
                                            Spacer(Modifier.weight(1f))
                                            IconButton(onClick = { editingAnnouncement = ann }, modifier = Modifier.size(28.dp)) { Icon(Icons.Filled.Edit, null, tint = BpcGreen, modifier = Modifier.size(18.dp)) }
                                            IconButton(onClick = { deleteAnnouncement(ann.id) }, modifier = Modifier.size(28.dp)) { Icon(Icons.Filled.Delete, null, tint = Color(0xFFE53935), modifier = Modifier.size(18.dp)) }
                                        }
                                        Text(ann.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BpcText)
                                        Text(ann.body, fontSize = 13.sp, color = BpcMuted, maxLines = 2)
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Offices / Directory
                    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Directory Offices (${offices.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BpcText)
                        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(offices, key = { it.name }) { office ->
                                Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(office.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BpcText)
                                            Text("Hours: ${office.hours}", fontSize = 12.sp, color = BpcMuted)
                                            Text("Contact: ${office.contact}", fontSize = 12.sp, color = BpcDarkGreen)
                                        }
                                        IconButton(onClick = { editingOffice = office }) { Icon(Icons.Filled.Edit, null, tint = BpcGreen) }
                                        IconButton(onClick = { deleteOffice(office) }) { Icon(Icons.Filled.Delete, null, tint = Color(0xFFE53935)) }
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    // Class Schedules
                    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Class Schedules (${classes.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BpcText)
                        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(classes, key = { "${it.id}-${it.day}-${it.time}-${it.subject}" }) { cls ->
                                Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text("For: ${cls.userEmail} • ${cls.day}: ${cls.time}", fontSize = 12.sp, color = BpcDarkGreen, fontWeight = FontWeight.SemiBold)
                                            Text(cls.subject, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BpcText)
                                            Text("Room: ${cls.roomId} • ${cls.instructor}", fontSize = 12.sp, color = BpcMuted)
                                        }
                                        IconButton(onClick = { editingClassItem = cls }) { Icon(Icons.Filled.Edit, null, tint = BpcGreen) }
                                        IconButton(onClick = { deleteClassItem(cls) }) { Icon(Icons.Filled.Delete, null, tint = Color(0xFFE53935)) }
                                    }
                                }
                            }
                        }
                    }
                }
                4 -> {
                    // Resources
                    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Campus Resources (${resources.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = BpcText)
                        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(resources, key = { it.title }) { res ->
                                Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(res.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BpcText)
                                            Text(res.desc, fontSize = 12.sp, color = BpcMuted)
                                        }
                                        IconButton(onClick = { editingResource = res }) { Icon(Icons.Filled.Edit, null, tint = BpcGreen) }
                                        IconButton(onClick = { deleteResource(res) }) { Icon(Icons.Filled.Delete, null, tint = Color(0xFFE53935)) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialogs
    if (showAddPlaceDialog) {
        PlaceDialog(title = "Add Location", place = null, onDismiss = { showAddPlaceDialog = false }, onSave = { addPlace(it); showAddPlaceDialog = false })
    }
    editingPlace?.let { p ->
        PlaceDialog(title = "Edit Location", place = p, onDismiss = { editingPlace = null }, onSave = { updatePlace(it); editingPlace = null; selectedPlaceOnMap = it })
    }

    if (showAddAnnouncementDialog) {
        AnnouncementDialog(title = "Add Announcement", announcement = null, onDismiss = { showAddAnnouncementDialog = false }, onSave = { addAnnouncement(it); showAddAnnouncementDialog = false })
    }
    editingAnnouncement?.let { ann ->
        AnnouncementDialog(title = "Edit Announcement", announcement = ann, onDismiss = { editingAnnouncement = null }, onSave = { updateAnnouncement(it); editingAnnouncement = null })
    }

    if (showAddOfficeDialog) {
        OfficeDialog(title = "Add Office", office = null, onDismiss = { showAddOfficeDialog = false }, onSave = { addOffice(it); showAddOfficeDialog = false })
    }
    editingOffice?.let { off ->
        OfficeDialog(title = "Edit Office", office = off, onDismiss = { editingOffice = null }, onSave = { updateOffice(off, it); editingOffice = null })
    }

    if (showAddClassDialog) {
        ClassDialog(title = "Add Schedule", classItem = null, onDismiss = { showAddClassDialog = false }, onSave = { addClassItem(it); showAddClassDialog = false })
    }
    editingClassItem?.let { cls ->
        ClassDialog(title = "Edit Schedule", classItem = cls, onDismiss = { editingClassItem = null }, onSave = { updateClassItem(cls, it); editingClassItem = null })
    }

    if (showAddResourceDialog) {
        ResourceDialog(title = "Add Resource", resource = null, onDismiss = { showAddResourceDialog = false }, onSave = { addResource(it); showAddResourceDialog = false })
    }
    editingResource?.let { res ->
        ResourceDialog(title = "Edit Resource", resource = res, onDismiss = { editingResource = null }, onSave = { updateResource(res, it); editingResource = null })
    }
}

@Composable
fun OfficeDialog(title: String, office: Office?, onDismiss: () -> Unit, onSave: (Office) -> Unit) {
    var name by remember { mutableStateOf(office?.name ?: "") }
    var placeId by remember { mutableStateOf(office?.placeId ?: "admin") }
    var hours by remember { mutableStateOf(office?.hours ?: "Mon-Fri, 8:00 AM - 5:00 PM") }
    var contact by remember { mutableStateOf(office?.contact ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(value = name, onChange = { name = it }, label = { Text("Office Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = placeId, onChange = { placeId = it }, label = { Text("Place ID (e.g. admin, main)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = hours, onChange = { hours = it }, label = { Text("Hours") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = contact, onChange = { contact = it }, label = { Text("Contact / Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = Color(0xFFE53935), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isBlank()) error = "Office name cannot be blank." else onSave(Office(name.trim(), placeId.trim(), hours.trim(), contact.trim()))
            }, colors = ButtonDefaults.buttonColors(containerColor = BpcGreen)) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = BpcMuted) } },
    )
}

@Composable
fun ClassDialog(title: String, classItem: ClassItem?, onDismiss: () -> Unit, onSave: (ClassItem) -> Unit) {
    var userEmail by remember { mutableStateOf(classItem?.userEmail ?: "all") }
    var day by remember { mutableStateOf(classItem?.day ?: DayOfWeek.MONDAY) }
    var time by remember { mutableStateOf(classItem?.time ?: "8:00 - 10:00 AM") }
    var subject by remember { mutableStateOf(classItem?.subject ?: "") }
    var roomId by remember { mutableStateOf(classItem?.roomId ?: "main") }
    var instructor by remember { mutableStateOf(classItem?.instructor ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(value = userEmail, onChange = { userEmail = it }, label = { Text("Designated User Email (or 'all')") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = subject, onChange = { subject = it }, label = { Text("Subject Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = time, onChange = { time = it }, label = { Text("Time (e.g. 8:00 - 10:00 AM)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = roomId, onChange = { roomId = it }, label = { Text("Room ID (e.g. main, comlab)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = instructor, onChange = { instructor = it }, label = { Text("Instructor") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = Color(0xFFE53935), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (subject.isBlank()) error = "Subject cannot be blank." else onSave(ClassItem(classItem?.id ?: java.util.UUID.randomUUID().toString(), userEmail.trim().ifBlank { "all" }, day, time.trim(), subject.trim(), roomId.trim(), instructor.trim()))
            }, colors = ButtonDefaults.buttonColors(containerColor = BpcGreen)) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = BpcMuted) } },
    )
}

@Composable
fun ResourceDialog(title: String, resource: Resource?, onDismiss: () -> Unit, onSave: (Resource) -> Unit) {
    var resTitle by remember { mutableStateOf(resource?.title ?: "") }
    var desc by remember { mutableStateOf(resource?.desc ?: "") }
    var placeId by remember { mutableStateOf(resource?.placeId ?: "library") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(value = resTitle, onChange = { resTitle = it }, label = { Text("Resource Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = desc, onChange = { desc = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = placeId, onChange = { placeId = it }, label = { Text("Place ID (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = Color(0xFFE53935), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (resTitle.isBlank()) error = "Title cannot be blank." else onSave(Resource(resTitle.trim(), desc.trim(), Icons.Outlined.MenuBook, placeId.takeIf { it.isNotBlank() }))
            }, colors = ButtonDefaults.buttonColors(containerColor = BpcGreen)) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = BpcMuted) } },
    )
}

@Composable
fun PlaceDialog(title: String, place: Place?, onDismiss: () -> Unit, onSave: (Place) -> Unit) {
    var id by remember { mutableStateOf(place?.id ?: "") }
    var name by remember { mutableStateOf(place?.name ?: "") }
    var category by remember { mutableStateOf(place?.category ?: "Academic") }
    var desc by remember { mutableStateOf(place?.desc ?: "") }
    var x by remember { mutableFloatStateOf(place?.x ?: 0.5f) }
    var y by remember { mutableFloatStateOf(place?.y ?: 0.5f) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().heightIn(max = 540.dp)) {
                if (place == null) {
                    OutlinedTextField(value = id, onChange = { id = it }, label = { Text("Unique ID (e.g. lab2)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(value = name, onChange = { name = it }, label = { Text("Location Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = category, onChange = { category = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = desc, onChange = { desc = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())

                Text("Pinch to zoom and tap on the map to position pin:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = BpcText)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFC7C8CD))
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val s = (scale * zoom).coerceIn(1f, 4f)
                                scale = s
                                offset = Offset(offset.x + pan.x, offset.y + pan.y)
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(ADMIN_MAP_ASPECT)
                            .graphicsLayer(
                                scaleX = scale, scaleY = scale,
                                translationX = offset.x, translationY = offset.y,
                            )
                            .pointerInput(Unit) {
                                detectTapGestures { tapOffset ->
                                    x = (tapOffset.x / size.width).coerceIn(0f, 1f)
                                    y = (tapOffset.y / size.height).coerceIn(0f, 1f)
                                }
                            }
                    ) {
                        Image(painterResource(com.bpc.campusnavigator.R.drawable.campus_map), "Campus map", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                        BoxWithConstraints(Modifier.fillMaxSize()) {
                            val mw = maxWidth
                            val mh = maxHeight
                            Box(Modifier.offset(mw * x - 12.dp, mh * y - 12.dp).size(24.dp), contentAlignment = Alignment.Center) {
                                Box(Modifier.size(16.dp).clip(CircleShape).background(BpcGold).border(2.dp, Color.White, CircleShape))
                            }
                        }
                    }
                }
                error?.let { Text(it, color = Color(0xFFE53935), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (id.isBlank() && place == null) error = "ID cannot be blank." else if (name.isBlank()) error = "Name cannot be blank." else onSave(Place(place?.id ?: id.trim(), name.trim(), x, y, category.trim(), desc.trim()))
            }, colors = ButtonDefaults.buttonColors(containerColor = BpcGreen)) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = BpcMuted) } },
    )
}

@Composable
fun AnnouncementDialog(title: String, announcement: Announcement?, onDismiss: () -> Unit, onSave: (Announcement) -> Unit) {
    val annId = announcement?.id ?: java.util.UUID.randomUUID().toString()
    var annTitle by remember { mutableStateOf(announcement?.title ?: "") }
    var annDate by remember { mutableStateOf(announcement?.date ?: "Oct 14, 2026") }
    var annTag by remember { mutableStateOf(announcement?.tag ?: "Update") }
    var annBody by remember { mutableStateOf(announcement?.body ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(value = annTitle, onChange = { annTitle = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = annDate, onChange = { annDate = it }, label = { Text("Date") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = annTag, onChange = { annTag = it }, label = { Text("Tag") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = annBody, onChange = { annBody = it }, label = { Text("Body") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = Color(0xFFE53935), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (annTitle.isBlank() || annBody.isBlank()) error = "Title and Body cannot be blank." else onSave(Announcement(annId, annTitle.trim(), annDate.trim(), annTag.trim(), annBody.trim()))
            }, colors = ButtonDefaults.buttonColors(containerColor = BpcGreen)) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = BpcMuted) } },
    )
}

@Composable
private fun OutlinedTextField(
    value: String,
    onChange: (String) -> Unit,
    label: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    singleLine: Boolean = false,
) {
    androidx.compose.material3.OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = label,
        singleLine = singleLine,
        modifier = modifier,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White,
            focusedBorderColor = BpcGreen,
            unfocusedBorderColor = BpcMint,
        ),
        shape = RoundedCornerShape(12.dp),
    )
}
