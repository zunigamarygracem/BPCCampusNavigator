package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.AuthState
import com.bpc.campusnavigator.User
import com.bpc.campusnavigator.ui.theme.*

@Composable
fun SignInScreen(onSuccess: () -> Unit, onNavigateSignUp: () -> Unit, onBack: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    ScreenScaffold("Sign In", "Access your BPC account") {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier.size(80.dp).background(BpcMint, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Person, null, tint = BpcDarkGreen, modifier = Alignment.Center.let { 40.dp }.let { Modifier.size(40.dp) })
            }
            Spacer(Modifier.height(24.dp))
            Text("Welcome Back!", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = BpcText)
            Text("Sign in to continue exploring BPC Campus", fontSize = 13.sp, color = BpcMuted)
            Spacer(Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = BpcGreen,
                            unfocusedBorderColor = BpcMint,
                        ),
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = BpcGreen,
                            unfocusedBorderColor = BpcMint,
                        ),
                    )
                    error?.let {
                        Text(it, color = Color(0xFFE53935), fontSize = 12.sp)
                    }
                    Button(
                        onClick = {
                            if (email.isBlank() || password.isBlank()) {
                                error = "Please enter email and password."
                            } else {
                                // Default or simulated sign in. If email contains admin or matches admin, make admin.
                                val isAdmin = email.contains("admin", ignoreCase = true)
                                val name = email.substringBefore("@").replaceFirstChar { it.uppercase() }
                                AuthState.currentUser.value = User(name = name, email = email, isAdmin = isAdmin)
                                onSuccess()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BpcGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                    ) {
                        Text("Sign In", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Don't have an account?", color = BpcMuted, fontSize = 14.sp)
                TextButton(onClick = onNavigateSignUp) {
                    Text("Sign Up", color = BpcDarkGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}
