package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Route
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.R
import com.bpc.campusnavigator.Place
import com.bpc.campusnavigator.places
import com.bpc.campusnavigator.ui.theme.*

private const val MAP_ASPECT = 1799f / 1272f

/** Pinch-to-zoom / drag campus map with tappable markers and an optional route line. */
@Composable
fun CampusMapView(
    modifier: Modifier = Modifier,
    selected: Place?,
    onSelect: (Place?) -> Unit,
    route: Pair<Place, Place>? = null,
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFFC7C8CD))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val s = (scale * zoom).coerceIn(1f, 5f)
                    val maxX = size.width * (s - 1f) / 2f
                    val maxY = size.height * (s - 1f) / 2f
                    offset = Offset(
                        (offset.x + pan.x).coerceIn(-maxX, maxX),
                        (offset.y + pan.y).coerceIn(-maxY, maxY),
                    )
                    scale = s
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(MAP_ASPECT)
                .graphicsLayer(
                    scaleX = scale, scaleY = scale,
                    translationX = offset.x, translationY = offset.y,
                )
        ) {
            Image(
                painterResource(R.drawable.campus_map), "Campus map",
                Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds,
            )
            if (route != null) {
                Canvas(Modifier.fillMaxSize()) {
                    val a = Offset(route.first.x * size.width, route.first.y * size.height)
                    val b = Offset(route.second.x * size.width, route.second.y * size.height)
                    drawLine(
                        BpcGold, a, b, strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(22f, 16f)),
                    )
                }
            }
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val w = maxWidth
                val h = maxHeight
                places.forEach { p ->
                    val isRouteEnd = route != null && (p.id == route.first.id || p.id == route.second.id)
                    val isSel = selected?.id == p.id
                    val dot = if (isSel || isRouteEnd) 16.dp else 9.dp
                    Box(
                        Modifier
                            .offset(w * p.x - 12.dp, h * p.y - 12.dp)
                            .size(24.dp)
                            .graphicsLayer(scaleX = 1f / scale, scaleY = 1f / scale)
                            .clip(CircleShape)
                            .clickable { onSelect(if (isSel) null else p) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            Modifier
                                .size(dot)
                                .clip(CircleShape)
                                .background(if (isSel || isRouteEnd) BpcGold else BpcDarkGreen)
                                .border(2.dp, Color.White, CircleShape)
                        )
                    }
                }
                // Name label for the selected place (the map image itself has no text).
                selected?.let { p ->
                    Box(
                        Modifier
                            .offset(w * p.x - 70.dp, h * p.y - 44.dp)
                            .width(140.dp)
                            .graphicsLayer(scaleX = 1f / scale, scaleY = 1f / scale),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            p.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(BpcDarkGreen)
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CampusMapScreen(initialPlaceId: String?, onRoute: (String) -> Unit) {
    var selected by remember { mutableStateOf(places.firstOrNull { it.id == initialPlaceId }) }
    var query by remember { mutableStateOf("") }
    val filtered = places.filter { it.name.contains(query, ignoreCase = true) }

    ScreenScaffold("Campus Map", "Find buildings & locations") {
        Column(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Search buildings, offices...") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                    focusedBorderColor = BpcGreen, unfocusedBorderColor = BpcMint,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered) { p ->
                    FilterChip(
                        selected = selected?.id == p.id,
                        onClick = { selected = p },
                        label = { Text(p.name) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BpcGreen, selectedLabelColor = Color.White,
                            containerColor = Color.White,
                        ),
                    )
                }
            }
            CampusMapView(
                Modifier.fillMaxWidth().weight(1f),
                selected = selected, onSelect = { selected = it },
            )
            selected?.let { p ->
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BpcText)
                            Text(p.desc, fontSize = 13.sp, color = BpcMuted)
                        }
                        Button(
                            onClick = { onRoute(p.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = BpcGreen),
                        ) {
                            Icon(Icons.Outlined.Route, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Route")
                        }
                    }
                }
            }
        }
    }
}
