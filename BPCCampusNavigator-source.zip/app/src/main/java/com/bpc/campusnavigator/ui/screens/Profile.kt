package com.bpc.campusnavigator.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bpc.campusnavigator.AuthState
import com.bpc.campusnavigator.User
import com.bpc.campusnavigator.ui.theme.*

@Composable
fun ProfileScreen(onOpenAdmin: () -> Unit, onNavigateSignIn: () -> Unit, onNavigateSignUp: () -> Unit) {
    val user = AuthState.currentUser.value
    var showEditDialog by remember { mutableStateOf(false) }

    ScreenScaffold("Profile", "Your BPC account") {
        Column(
            Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Box(Modifier.size(96.dp).background(BpcGreen, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(60.dp))
            }

            if (user != null) {
                Text(user.name, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = BpcText)
                Text(user.email, color = BpcMuted)
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (user.isAdmin) BpcDarkGreen else BpcMint,
                ) {
                    Text(
                        if (user.isAdmin) "Administrator (MA-00000000)" else "BPCian Student",
                        color = if (user.isAdmin) Color.White else BpcDarkGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    )
                }
            } else {
                Text("Guest User", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = BpcText)
                Text("Bulacan Polytechnic College", color = BpcMuted)
            }

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Malolos, Bulacan  -  Est. 1971", color = BpcText, fontWeight = FontWeight.SemiBold)
                    Text("Education Today, A Brighter Tomorrow", color = BpcMuted, fontSize = 14.sp)
                    Text("BPC Campus Navigator v1.0", color = BpcMuted, fontSize = 12.sp)
                }
            }

            if (user != null) {
                OutlinedButton(
                    onClick = { showEditDialog = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BpcDarkGreen),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Filled.Edit, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Edit Profile", fontSize = 15.sp)
                }

                if (user.isAdmin) {
                    Button(
                        onClick = onOpenAdmin,
                        colors = ButtonDefaults.buttonColors(containerColor = BpcDarkGreen),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.AdminPanelSettings, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Admin: Map & Announcements Editor", fontSize = 15.sp)
                    }
                }
                OutlinedButton(
                    onClick = { AuthState.currentUser.value = null },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE53935)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Filled.ExitToApp, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Sign Out", fontSize = 16.sp)
                }
            } else {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = onNavigateSignIn,
                        colors = ButtonDefaults.buttonColors(containerColor = BpcGreen),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.Login, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Sign In")
                    }
                    Button(
                        onClick = onNavigateSignUp,
                        colors = ButtonDefaults.buttonColors(containerColor = BpcDarkGreen),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.PersonAdd, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Sign Up")
                    }
                }
            }
        }
    }

    if (showEditDialog && user != null) {
        EditProfileDialog(
            user = user,
            onDismiss = { showEditDialog = false },
            onSave = { updated ->
                AuthState.currentUser.value = updated
                showEditDialog = false
            },
        )
    }
}

@Composable
fun EditProfileDialog(user: User, onDismiss: () -> Unit, onSave: (User) -> Unit) {
    var name by remember { mutableStateOf(user.name) }
    var email by remember { mutableStateOf(user.email) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Profile", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = name,
                    onChange = { name = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = email,
                    onChange = { email = it },
                    label = { Text("Email Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                error?.let { Text(it, color = Color(0xFFE53935), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank() || email.isBlank()) {
                        error = "Name and email cannot be blank."
                    } else {
                        onSave(User(name = name.trim(), email = email.trim(), isAdmin = user.isAdmin))
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BpcGreen),
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = BpcMuted) }
        },
    )
}

@Composable
private fun OutlinedTextField(
    value: String,
    onChange: (String) -> Unit,
    label: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    singleLine: Boolean = false,
) {
    androidx.compose.material3.OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = label,
        singleLine = singleLine,
        modifier = modifier,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White,
            focusedBorderColor = BpcGreen,
            unfocusedBorderColor = BpcMint,
        ),
        shape = RoundedCornerShape(12.dp),
    )
}
